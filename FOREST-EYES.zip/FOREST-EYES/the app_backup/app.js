/**
 * ForestWatch — Deforestation Intelligence Platform
 * =================================================
 * Full API integration extracted from the wri/gfw GitHub repository:
 *
 *   1. GFW Data API       → https://data-api.globalforestwatch.org
 *      - Geostore (create/fetch areas from GeoJSON)
 *      - Tree cover loss (precomputed datasets by admin/geostore)
 *      - GLAD / Integrated deforestation alerts
 *      - FAO forest data (extent, deforestation rates, reforestation)
 *      - Biomass & carbon stock
 *
 *   2. Resource Watch API  → https://api.resourcewatch.org
 *      - Analysis endpoints (UMD loss/gain by admin/geostore/wdpa)
 *      - Climate cumulative emissions & deforestation tracking
 *      - Recent satellite tiles (Landsat via lat/lng)
 *
 *   3. GNW Analytics API   → https://analytics.globalnaturewatch.org
 *      - On-the-fly tree cover loss analytics for arbitrary GeoJSON polygons
 *
 *   4. Climate Watch API   → https://www.climatewatchdata.org/api/v1
 *      - Greenhouse gas emissions metadata & data (CO2, CH4, N2O by country)
 *
 *   5. Open-Meteo          → https://api.open-meteo.com   (free, no key)
 *      - Real-time weather (temperature, humidity, precipitation, wind)
 *
 *   6. Nominatim (OSM)     → https://nominatim.openstreetmap.org (free)
 *      - Location name search / geocoding
 */

// =============================================
// API BASE URLS (extracted from utils/apis.js)
// =============================================
const APIS = {
  GFW_DATA:          'https://data-api.globalforestwatch.org',
  RESOURCE_WATCH:    'https://api.resourcewatch.org/v1',
  GFW_API:           'https://api.resourcewatch.org',
  GNW_ANALYTICS:     'https://analytics.globalnaturewatch.org',
  CLIMATE_WATCH:     'https://www.climatewatchdata.org/api/v1',
  OPEN_METEO:        'https://api.open-meteo.com/v1',
  NOMINATIM:         'https://nominatim.openstreetmap.org',
};

// GFW API Key for authenticated requests
const GFW_API_KEY = '8796c443-5825-40a9-9db9-4a89b89e25d4';

// Analysis dataset tables (from data/analysis-datasets.json)
const DATASETS = {
  ANNUAL_GEOSTORE_SUMMARY: 'geostore__tcl__summary',
  ANNUAL_GEOSTORE_CHANGE:  'geostore__tcl__change',
  GLAD_GEOSTORE_DAILY:     'geostore__glad__daily_alerts',
  INTEGRATED_ALERTS_GEOSTORE_DAILY: 'geostore__integrated_alerts__daily_alerts',
};

// =============================================
// MAP INITIALIZATION
// =============================================
const map = L.map('map', {
  center: [20, 0],
  zoom: 3,
  zoomControl: false,
});

// Base layers
const darkBase = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
  attribution: '&copy; OpenStreetMap &copy; CARTO',
  maxZoom: 19,
});

const satelliteBase = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
  attribution: '&copy; Esri, Maxar, Earthstar Geographics',
  maxZoom: 19,
});

// GFW Data Layers (from tiles.globalforestwatch.org — extracted from repo configs)
const treeCoverLayer = L.tileLayer('https://tiles.globalforestwatch.org/umd_tree_cover_density_2000/v1_8/tcd_30/{z}/{x}/{y}.png', {
  maxZoom: 12,
  opacity: 0.7,
  attribution: 'Tree Cover 2000 &copy; UMD/Hansen/Google/USGS/NASA',
});

const treeLossLayer = L.tileLayer('https://tiles.globalforestwatch.org/umd_tree_cover_loss/v1.11/tcd_30/{z}/{x}/{y}.png', {
  maxZoom: 12,
  opacity: 0.85,
  attribution: 'Tree Cover Loss &copy; UMD/Hansen/Google/USGS/NASA',
});

const gladAlertsLayer = L.tileLayer('https://tiles.globalforestwatch.org/glad_prod/tiles/{z}/{x}/{y}.png', {
  maxZoom: 12,
  opacity: 0.9,
  attribution: 'GLAD Alerts &copy; UMD/GLAD',
});
const treeLossColorLayer = L.layerGroup();

// Add default layers to map
satelliteBase.addTo(map);
treeCoverLayer.addTo(map);
treeLossLayer.addTo(map);

L.control.zoom({ position: 'bottomright' }).addTo(map);

// =============================================
// LAYER TOGGLE CONTROLS
// =============================================
// Safely bind layer toggles (they may not exist if HTML hasn't loaded yet)
function bindToggle(id, onCheck, onUncheck) {
  const el = document.getElementById(id);
  if (el) el.addEventListener('change', (e) => e.target.checked ? onCheck() : onUncheck());
}

bindToggle('toggle-satellite',
  () => { map.removeLayer(darkBase); map.addLayer(satelliteBase); },
  () => { map.removeLayer(satelliteBase); map.addLayer(darkBase); }
);
bindToggle('toggle-tree-cover',
  () => map.addLayer(treeCoverLayer),
  () => map.removeLayer(treeCoverLayer)
);
bindToggle('toggle-tree-loss',
  () => syncTreeLossLayer(),
  () => syncTreeLossLayer()
);
bindToggle('toggle-glad',
  () => map.addLayer(gladAlertsLayer),
  () => map.removeLayer(gladAlertsLayer)
);

// State
let currentMarker = null;
let currentPolygon = null;
let lastLat = null;
let lastLng = null;
let lastName = null;
let latestApiUpdatedAt = null;
let latestLossRows = [];
let latestLossCenter = null;
let globeScene = null;

// =============================================
// APP STATE — Dual-Cache Architecture
// Keeps API and simulated data in completely
// separate stores keyed by "lat,lng" location ID.
// =============================================
const appState = {
  /** @type {Object<string, {raw: Object, formatted: Object, locationName: string, lat: number, lng: number}>} */
  apiCache: {},
  /** @type {Object<string, {raw: Object, formatted: Object, locationName: string, lat: number, lng: number}>} */
  simCache: {},
  /** Currently displayed location ID ("lat,lng") or null */
  activeLocationId: null,
};

/** Produce a stable cache key from coordinates (rounded to 4 dp to avoid float dust). */
function locationId(lat, lng) {
  return `${lat.toFixed(4)},${lng.toFixed(4)}`;
}

const $ = id => document.getElementById(id);
const $latInput       = $('lat-input');
const $lngInput       = $('lng-input');
const $radiusInput    = $('radius-input');
const $radiusDisplay  = $('radius-display');
const $locationSearch = $('location-search');
const $searchBtn      = $('search-btn');
const $analyzeBtn     = $('analyze-btn');
const $retryBtn       = $('retry-btn');
const $statusDot      = $('status-dot');
const $statusText     = $('status-text');

const $resultPlaceholder  = $('result-placeholder');

function extractApiUpdatedAt(body, response) {
  return body?.meta?.updated_at || body?.metadata?.updated_at || body?.data?.updated_at ||
    response.headers.get('last-modified') || response.headers.get('date') || null;
}
const $resultContent      = $('result-content');
const $loadingState       = $('loading-state');
const $errorState         = $('error-state');
const $errorMessage       = $('error-message');
const $resultLocationName = $('result-location-name');
const $severityCard       = $('severity-card');
const $severityIcon       = $('severity-icon');
const $severityLevel      = $('severity-level');
const $severityDesc       = $('severity-desc');
const $statHa             = $('stat-ha');
const $statCo2            = $('stat-co2');
const $statYears          = $('stat-years');
const $statTrees          = $('stat-trees');
const $barChart           = $('bar-chart');
const $plantingNumber     = $('planting-number');
const $apiUpdated         = $('api-updated');
const $recentSearches     = $('recent-searches');
const $searchSuggestions  = $('search-suggestions');
const $globeContainer      = $('globe-container');
const $globeControls       = $('globe-controls');
const $treeLossMode        = $('tree-loss-mode');
const $toggleRealApi       = $('toggle-real-api');
const $toggleSimulate      = $('toggle-simulate');
const $dataSourceHint      = $('data-source-hint');

if ($treeLossMode) $treeLossMode.addEventListener('change', syncTreeLossLayer);

// =============================================
// DATA SOURCE TOGGLE
// =============================================
function getDataSourceMode() {
  return $toggleRealApi?.checked ? 'real' : 'simulate';
}

function updateDataSourceHint() {
  if (!$dataSourceHint) return;
  if (getDataSourceMode() === 'real') {
    $dataSourceHint.textContent = 'Using live GFW API with authentication';
    $dataSourceHint.style.color = 'rgba(0, 230, 118, 0.5)';
  } else {
    $dataSourceHint.textContent = 'Using simulated biome estimates';
    $dataSourceHint.style.color = '';
  }
}

/**
 * When the user flips the toggle, instantly swap the displayed data
 * from the correct cache — no re-fetch, no re-simulation.
 * Uses structuredClone to guarantee zero mutation of cached data.
 */
function onDataSourceToggle() {
  updateDataSourceHint();

  const locId = appState.activeLocationId;
  if (!locId) return; // nothing analysed yet

  const mode  = getDataSourceMode();
  const cache = mode === 'real' ? appState.apiCache : appState.simCache;
  const entry = cache[locId];

  if (!entry) {
    // No cached data for this mode yet — tell the user
    const label = mode === 'real' ? 'Live API' : 'Simulated';
    $apiUpdated.textContent = `${label} data not yet available for this location — click Analyze.`;
    return;
  }

  // Deep-clone so the chart / UI can never mutate our cache
  const safeData = structuredClone(entry.formatted);
  renderDeforestationResults(entry.lat, entry.lng, entry.locationName, safeData, mode);
  setStatus('ready', `Switched to ${mode === 'real' ? 'Live API' : 'Simulated'} data`);
}

if ($toggleRealApi)  $toggleRealApi.addEventListener('change', onDataSourceToggle);
if ($toggleSimulate) $toggleSimulate.addEventListener('change', onDataSourceToggle);

const globeToggle = $('toggle-globe');
if (globeToggle) globeToggle.addEventListener('change', (event) => {
  const showGlobe = event.target.checked;
  $globeContainer.classList.toggle('hidden', !showGlobe);
  $globeControls?.classList.toggle('hidden', !showGlobe);
  $('map').classList.toggle('hidden', showGlobe);
  if (showGlobe) {
    initGlobe();
    resizeGlobe();
  }
});

const $climatePlaceholder = $('climate-placeholder');
const $climateContent     = $('climate-content');
const $cvTemp             = $('cv-temp');
const $cvHumidity         = $('cv-humidity');
const $cvPrecip           = $('cv-precip');
const $cvWind             = $('cv-wind');
const $cbTemp             = $('cb-temp');
const $cbHumidity         = $('cb-humidity');
const $cbPrecip           = $('cb-precip');
const $cbWind             = $('cb-wind');
const $gwGaugeFill        = $('gw-gauge-fill');
const $gwLabel            = $('gw-label');
const $gwDescription      = $('gw-description');

const $steps = [1,2,3,4].map(i => $(`step-${i}`));

// =============================================
// RADIUS SLIDER
// =============================================
$radiusInput.addEventListener('input', () => {
  const val = $radiusInput.value;
  $radiusDisplay.textContent = `${val} km`;
  const pct = ((val - 1) / (50 - 1)) * 100;
  $radiusInput.style.background = `linear-gradient(to right, #00e676 0%, #00e676 ${pct}%, rgba(255,255,255,0.1) ${pct}%)`;
});

// =============================================
// MAP CLICK — fills coords
// =============================================
map.on('click', (e) => {
  $latInput.value = e.latlng.lat.toFixed(6);
  $lngInput.value = e.latlng.lng.toFixed(6);
  lastName = null;
  if(typeof updatePrefixes === 'function') updatePrefixes();
});

// =============================================
// GEOCODING (Nominatim — from services/geocoding.js pattern)
// =============================================
async function geocodeLocation(query) {
  const url = `${APIS.NOMINATIM}/search?q=${encodeURIComponent(query)}&format=json&limit=1`;
  const res = await fetch(url, { headers: { 'Accept-Language': 'en' } });
  const data = await res.json();
  if (!data || data.length === 0) throw new Error('Location not found. Try a different search term.');
  return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon), name: data[0].display_name };
}

$searchBtn.addEventListener('click', doSearch);
$locationSearch.addEventListener('keydown', (e) => { if (e.key === 'Enter') doSearch(); });

let suggestionTimer = null;
$locationSearch.addEventListener('input', () => {
  clearTimeout(suggestionTimer);
  const query = $locationSearch.value.trim();
  if (query.length < 3) {
    $searchSuggestions.classList.add('hidden');
    return;
  }
  suggestionTimer = setTimeout(() => loadSearchSuggestions(query), 350);
});

document.addEventListener('click', (e) => {
  if (!$searchSuggestions.contains(e.target) && e.target !== $locationSearch) {
    $searchSuggestions.classList.add('hidden');
  }
});

async function loadSearchSuggestions(query) {
  try {
    const url = `${APIS.NOMINATIM}/search?q=${encodeURIComponent(query)}&format=json&limit=5`;
    const res = await fetch(url, { headers: { 'Accept-Language': 'en' } });
    const places = await res.json();
    $searchSuggestions.innerHTML = '';
    places.forEach(place => {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'search-suggestion';
      item.textContent = place.display_name;
      item.addEventListener('click', () => {
        $locationSearch.value = place.display_name;
        $searchSuggestions.classList.add('hidden');
        applyLocation(parseFloat(place.lat), parseFloat(place.lon), place.display_name);
      });
      $searchSuggestions.appendChild(item);
    });
    $searchSuggestions.classList.toggle('hidden', places.length === 0);
  } catch (err) {
    $searchSuggestions.classList.add('hidden');
  }
}

async function doSearch() {
  const query = $locationSearch.value.trim();
  if (!query) return;
  setStatus('loading', 'Searching location...');
  try {
    const { lat, lng, name } = await geocodeLocation(query);
    applyLocation(lat, lng, name);
    setStatus('ready', 'Location found — click Analyze');
  } catch (err) {
    setStatus('error', err.message);
  }
}

function applyLocation(lat, lng, name) {
  $latInput.value = lat.toFixed(6);
  $lngInput.value = lng.toFixed(6);
  lastName = name.split(',').slice(0, 2).join(',');
  $locationSearch.value = lastName;
  map.setView([lat, lng], 10);
  focusGlobeOnCoordinates(lat, lng);
  saveRecentSearch({ lat, lng, name: lastName });
  if (typeof updatePrefixes === 'function') updatePrefixes();
}

// =============================================
// PRESET BUTTONS
// =============================================
function saveRecentSearch(search) {
  const stored = JSON.parse(localStorage.getItem('forestwatch-recent-searches') || '[]');
  const next = [search, ...stored.filter(item => item.name !== search.name)].slice(0, 6);
  localStorage.setItem('forestwatch-recent-searches', JSON.stringify(next));
  renderRecentSearches(next);
}

function renderRecentSearches(searches = JSON.parse(localStorage.getItem('forestwatch-recent-searches') || '[]')) {
  if (!$recentSearches) return;
  $recentSearches.innerHTML = '';
  if (!searches.length) {
    $recentSearches.innerHTML = '<p class="empty-recent">Your searched locations will appear here.</p>';
    return;
  }
  searches.forEach(search => {
    const button = document.createElement('button');
    button.className = 'btn-preset';
    button.textContent = `📍 ${search.name}`;
    button.title = `Load ${search.name}`;
    button.addEventListener('click', () => {
      applyLocation(search.lat, search.lng, search.name);
      setStatus('ready', `${search.name} loaded — click Analyze`);
    });
    $recentSearches.appendChild(button);
  });
}

// =============================================
// ANALYZE BUTTON
// =============================================
$analyzeBtn.addEventListener('click', () => {
  const lat = parseFloat($latInput.value);
  const lng = parseFloat($lngInput.value);
  if (isNaN(lat) || isNaN(lng)) {
    showError('Please enter valid latitude and longitude, or search for a location.');
    return;
  }
  if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
    showError('Coordinates out of range. Latitude: -90 to 90. Longitude: -180 to 180.');
    return;
  }
  analyzeLocation(lat, lng);
});

$retryBtn.addEventListener('click', () => {
  if (lastLat !== null && lastLng !== null) analyzeLocation(lastLat, lastLng);
});

// =============================================
//  CORE: ANALYZE LOCATION
//  In 'real' mode  → GFW Data API → GNW fallback (no simulation)
//  In 'simulate'   → pure biome-based estimate (no API calls)
//  Results are stored in the appropriate cache.
// =============================================
async function analyzeLocation(lat, lng) {
  lastLat = lat;
  lastLng = lng;
  const radiusKm = parseInt($radiusInput.value);
  const locationName = lastName || `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  const mode  = getDataSourceMode();
  const locId = locationId(lat, lng);

  // Clear *visual* UI for the new analysis, but caches survive
  showLoading();
  setStatus('loading', mode === 'real' ? 'Fetching live satellite data…' : 'Simulating analysis…');
  clearMapLayers();
  appState.activeLocationId = locId;
  map.setView([lat, lng], 9);
  focusGlobeOnCoordinates(lat, lng);

  try {
    // STEP 1 — Build GeoJSON bounding box
    setStep(0);
    const geojson = createBoundingBoxGeoJSON(lat, lng, radiusKm);
    drawPolygon(geojson);
    await delay(400);

    let analyticsData = null;

    if (mode === 'real') {
      // ——— REAL API MODE ———
      setStep(1);
      try {
        console.log('[API] Mode: REAL API — Strategy 1: GFW Data API');
        const geostoreId = await createGeostore(geojson);
        console.log('[API] Geostore created:', geostoreId);
        analyticsData = await queryTreeCoverLossDataset(geostoreId);
        console.log('[API] GFW Data API returned data');
      } catch (gfwErr) {
        console.warn('[API] GFW Data API failed:', gfwErr.message);
        try {
          console.log('[API] Mode: REAL API — Strategy 2: GNW Analytics API');
          const resourceId = await triggerGNWAnalyticsJob(geojson);
          setStep(2);
          analyticsData = await pollGNWAnalyticsJob(resourceId);
          console.log('[API] GNW Analytics API returned data');
        } catch (gnwErr) {
          console.warn('[API] GNW Analytics API also failed:', gnwErr.message);
          throw new Error('All real API sources failed. Try switching to Simulate mode, or try again later.');
        }
      }
    } else {
      // ——— SIMULATE MODE (pure, from-scratch, no API data) ———
      setStep(1);
      console.log('[SIM] Mode: SIMULATE — generating fresh biome estimate');
      await delay(600);
      setStep(2);
      analyticsData = simulateAnalyticsData(lat, lng);
      await delay(400);
    }

    // STEP 3 — Format & store into the correct cache
    setStep(2);
    await delay(300);
    setStep(3);
    await delay(200);

    const formatted = formatAnalyticsResponse(analyticsData);
    latestApiUpdatedAt = analyticsData?.updatedAt || null;

    // ---- CACHE WRITE (strict isolation) ----
    const cacheEntry = {
      raw: analyticsData,
      formatted,
      locationName,
      lat,
      lng,
    };
    if (mode === 'real') {
      appState.apiCache[locId] = cacheEntry;
      console.log(`[CACHE] apiCache["${locId}"] written`);
    } else {
      appState.simCache[locId] = cacheEntry;
      console.log(`[CACHE] simCache["${locId}"] written`);
    }

    // ---- RENDER from a deep clone (zero mutation guarantee) ----
    const safeData = structuredClone(formatted);
    renderDeforestationResults(lat, lng, locationName, safeData, mode);

    // Climate data (fires in parallel)
    fetchAndRenderClimate(lat, lng, safeData.totalHa);

    setStatus('ready', `Analysis complete — ${locationName}`);

  } catch (err) {
    console.error('Analysis failed:', err);
    showError(`Analysis failed: ${err.message}. Please try again.`);
    setStatus('error', 'Analysis failed');
  } finally {
    if ($analyzeBtn) $analyzeBtn.disabled = false;
  }
}

// =============================================
// GEO HELPERS
// =============================================
function createBoundingBoxGeoJSON(lat, lng, radiusKm) {
  const latDelta = radiusKm / 111.0;
  const lngDelta = radiusKm / (111.0 * Math.cos(lat * Math.PI / 180));

  return {
    type: 'FeatureCollection',
    features: [{
      type: 'Feature',
      id: `fw-${Date.now()}`,
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [lng - lngDelta, lat - latDelta],
          [lng + lngDelta, lat - latDelta],
          [lng + lngDelta, lat + latDelta],
          [lng - lngDelta, lat + latDelta],
          [lng - lngDelta, lat - latDelta],
        ]],
      },
      properties: {},
    }],
  };
}

function drawPolygon(geojson) {
  const coords = geojson.features[0].geometry.coordinates[0];
  const leafletCoords = coords.map(c => [c[1], c[0]]);
  currentPolygon = L.polygon(leafletCoords, {
    color: 'rgba(66, 165, 245, 0.8)',
    weight: 2,
    fillColor: 'rgba(66, 165, 245, 0.06)',
    fillOpacity: 1,
    dashArray: '6 4',
  }).addTo(map);
}

// =============================================
// API 1: GFW DATA API — Geostore + Dataset Query
// (from services/geostore.js — saveGeostore)
// =============================================
async function createGeostore(geojson) {
  const headers = { 'Content-Type': 'application/json' };
  // Include API key when in Real API mode
  if (getDataSourceMode() === 'real' && GFW_API_KEY) {
    headers['x-api-key'] = GFW_API_KEY;
  }
  const res = await fetch(`${APIS.GFW_API}/geostore/`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ geojson }),
  });
  if (!res.ok) throw new Error(`Geostore creation failed: ${res.status}`);
  const data = await res.json();
  const hash = data?.data?.attributes?.hash || data?.data?.id;
  if (!hash) throw new Error('No geostore hash in response');
  return hash;
}

// Query precomputed tree cover loss dataset by geostore
// (from services/analysis-cached.js — SQL_QUERIES.loss pattern)
async function queryTreeCoverLossDataset(geostoreId) {
  const dataset = DATASETS.ANNUAL_GEOSTORE_SUMMARY;
  const sql = encodeURIComponent(
    `SELECT umd_tree_cover_loss__year, ` +
    `SUM(umd_tree_cover_loss__ha) AS umd_tree_cover_loss__ha, ` +
    `SUM("gfw_gross_emissions_co2e_all_gases__Mg") AS gfw_gross_emissions_co2e_all_gases__Mg ` +
    `FROM data ` +
    `WHERE umd_tree_cover_density_2000__threshold >= 30 ` +
    `GROUP BY umd_tree_cover_loss__year ` +
    `ORDER BY umd_tree_cover_loss__year`
  );

  const url = `${APIS.GFW_DATA}/dataset/${dataset}/latest/query?sql=${sql}&geostore_id=${geostoreId}&geostore_origin=rw`;
  const headers = {};
  if (getDataSourceMode() === 'real' && GFW_API_KEY) {
    headers['x-api-key'] = GFW_API_KEY;
  }
  const res = await fetch(url, { headers });
  if (!res.ok) throw new Error(`Dataset query failed: ${res.status}`);
  const body = await res.json();
  const rows = body?.data?.data || body?.data || [];
  if (!rows.length) throw new Error('No data rows returned from GFW Data API');

  // Transform to our standard format
  return {
    result: {
      tree_cover_loss_year: rows.map(r => r.umd_tree_cover_loss__year),
      area_ha: rows.map(r => r.umd_tree_cover_loss__ha || 0),
      carbon_emissions_MgCO2e: rows.map(r => r.gfw_gross_emissions_co2e_all_gases__Mg || 0),
    },
    updatedAt: extractApiUpdatedAt(body, res),
  };
}

// =============================================
// API 2: GNW ANALYTICS API
// (from utils/gnw-data-request.js)
// =============================================
async function triggerGNWAnalyticsJob(geojson) {
  const payload = {
    aoi: {
      type: 'feature_collection',
      feature_collection: geojson,
    },
    start_year: '2021',
    end_year: '2024',
    forest_filter: 'natural_forest',
    intersections: [],
  };

  const res = await fetch(`${APIS.GNW_ANALYTICS}/v0/land_change/tree_cover_loss/analytics`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`GNW Analytics POST failed: ${res.status}`);
  const data = await res.json();
  const link = data?.data?.link;
  if (!link) throw new Error('No resource link in GNW response');
  return link.split('/').pop();
}

async function pollGNWAnalyticsJob(resourceId) {
  const maxWait = 35000;
  let waited = 0;
  while (waited < maxWait) {
    const res = await fetch(`${APIS.GNW_ANALYTICS}/v0/land_change/tree_cover_loss/analytics/${resourceId}`);
    if (!res.ok) throw new Error(`GNW poll failed: ${res.status}`);
    const body = await res.json();
    const jobData = body?.data || body;
    const status = jobData?.status;
    if (status === 'saved' || status === 'success') return jobData;
    if (status === 'failed') throw new Error('GNW analytics job failed');
    const retryAfter = parseInt(res.headers.get('retry-after') || '2', 10) * 1000;
    await delay(retryAfter);
    waited += retryAfter;
  }
  throw new Error('GNW analytics job timed out');
}

// =============================================
// SIMULATED ESTIMATE — Pure Function
// Generates from scratch every call.
// Never reads, merges, or references API data.
//
// Constraints:
//   • Latitude-based biome baseline (tropical → boreal)
//   • Bounded year-over-year variance: ±30 %
//   • CO₂ keyed to area via a biome-specific
//     emission factor (Mg CO₂e per ha)
// =============================================
function simulateAnalyticsData(lat, lng) {
  const absLat = Math.abs(lat);

  // 1. Biome-specific baseline (ha/yr) and emission factor
  let baseLoss, emissionFactor;
  if (absLat < 10) {
    // Equatorial rainforest belt
    baseLoss       = 80 + Math.random() * 120;  // 80 – 200 ha
    emissionFactor = 350 + Math.random() * 100;  // dense biomass
  } else if (absLat < 23.5) {
    // Tropical / subtropical
    baseLoss       = 30 + Math.random() * 70;   // 30 – 100 ha
    emissionFactor = 280 + Math.random() * 80;
  } else if (absLat < 35) {
    // Warm temperate / Mediterranean
    baseLoss       = 8 + Math.random() * 30;    // 8 – 38 ha
    emissionFactor = 200 + Math.random() * 60;
  } else if (absLat < 55) {
    // Cool temperate / mixed forest
    baseLoss       = 2 + Math.random() * 15;    // 2 – 17 ha
    emissionFactor = 150 + Math.random() * 50;
  } else {
    // Boreal / tundra
    baseLoss       = 0.1 + Math.random() * 3;   // 0.1 – 3.1 ha
    emissionFactor = 80 + Math.random() * 40;
  }

  // 2. Generate 10 years with bounded ±30 % YoY variance
  const startYear = 2015;
  const numYears  = 10;
  const years     = [];
  const areaHa    = [];
  const emissions = [];

  let prevLoss = baseLoss;
  for (let i = 0; i < numYears; i++) {
    // Random change within [-0.30, +0.30] of previous year
    const change = (Math.random() * 0.6) - 0.3;          // –30 % … +30 %
    let   loss   = prevLoss * (1 + change);
    loss = Math.max(loss, 0.01);                          // floor to avoid negatives
    loss = parseFloat(loss.toFixed(2));

    const co2  = parseFloat((loss * emissionFactor).toFixed(2));

    years.push(startYear + i);
    areaHa.push(loss);
    emissions.push(co2);

    prevLoss = loss;
  }

  return {
    result: {
      tree_cover_loss_year:    years,
      area_ha:                 areaHa,
      carbon_emissions_MgCO2e: emissions,
    },
  };
}

// =============================================
// FORMAT RESPONSE (mirrors gnw-data-request.js formatLegacyResponse)
// =============================================
function formatAnalyticsResponse(data) {
  const result = data?.result || data;
  const years      = result?.tree_cover_loss_year || [];
  const areaHa     = result?.area_ha || [];
  const emissions  = result?.carbon_emissions_MgCO2e || [];

  const rows = years.map((year, i) => ({
    year,
    ha: areaHa[i] || 0,
    emissions: emissions[i] || 0,
  })).sort((a, b) => a.year - b.year);

  const totalHa        = rows.reduce((s, r) => s + r.ha, 0);
  const totalEmissions = rows.reduce((s, r) => s + r.emissions, 0);
  const treesNeeded    = calculateTreesNeeded(totalEmissions, totalHa);

  return { rows, totalHa, totalEmissions, treesNeeded, updatedAt: data?.updatedAt || null };
}

// =============================================
// SEVERITY ENGINE
// =============================================
function getSeverityLevel(totalHa) {
  if (totalHa > 100) return {
    level: 'VERY HIGH DEFORESTATION',
    color: 'red',
    icon: '🔴',
    desc: 'Critical deforestation detected. Immediate intervention required to prevent further ecosystem collapse.',
  };
  if (totalHa > 10) return {
    level: 'MODERATE DEFORESTATION',
    color: 'orange',
    icon: '🟠',
    desc: 'Significant tree cover loss identified. Monitoring and targeted reforestation recommended.',
  };
  if (totalHa > 1) return {
    level: 'LOW DEFORESTATION',
    color: 'yellow',
    icon: '🟡',
    desc: 'Minor deforestation detected. Area should be monitored for future changes.',
  };
  return {
    level: 'NEGLIGIBLE DEFORESTATION',
    color: 'green',
    icon: '🟢',
    desc: 'Little to no deforestation detected. This area appears well-preserved.',
  };
}

function calculateTreesNeeded(totalEmissions, totalHa) {
  const matureTrees = Math.ceil(totalEmissions / 0.021);
  const plantingGoal = Math.ceil(matureTrees * 3.5);
  const areaBasedEstimate = Math.ceil(totalHa * 400);
  return Math.max(plantingGoal, areaBasedEstimate);
}

// =============================================
// RENDER DEFORESTATION RESULTS
// @param {string} source — 'real' | 'simulate'  (controls badge text)
// =============================================
function renderDeforestationResults(lat, lng, locationName, data, source) {
  const { rows, totalHa, totalEmissions, treesNeeded } = data;
  const severity = getSeverityLevel(totalHa);

  $resultLocationName.textContent = `📍 ${locationName}`;

  // Show data origin badge
  if (source === 'real') {
    $apiUpdated.textContent = data.updatedAt
      ? `🟢 Live API data — updated ${formatDate(data.updatedAt)}`
      : '🟢 Live API data';
    $apiUpdated.style.color = 'rgba(0, 230, 118, 0.7)';
  } else {
    $apiUpdated.textContent = '🔵 Simulated biome estimate';
    $apiUpdated.style.color = 'rgba(66, 165, 245, 0.7)';
  }

  $severityCard.className = `severity-card ${severity.color}`;
  $severityIcon.textContent = severity.icon;
  $severityLevel.textContent = severity.level;
  $severityDesc.textContent = severity.desc;

  $statHa.textContent    = formatNumber(totalHa, 1);
  $statCo2.textContent   = formatNumber(totalEmissions, 0);
  const minYear = rows.length ? rows[0].year : '—';
  const maxYear = rows.length ? rows[rows.length - 1].year : '—';
  $statYears.textContent = `${minYear}–${maxYear}`;
  $statTrees.textContent = formatCompact(treesNeeded);

  renderBarChart(rows, severity.color);
  renderTreeLossColorForm(lat, lng, rows);

  $plantingNumber.textContent = formatNumber(treesNeeded, 0);

  placeMarker(lat, lng, severity);

  $loadingState.classList.add('hidden');
  $resultContent.classList.remove('hidden');
}

// =============================================
// BAR CHART
// =============================================
function renderBarChart(rows, color) {
  $barChart.innerHTML = '';
  const maxHa = Math.max(...rows.map(r => r.ha), 0.01);
  rows.forEach(row => {
    const pct = Math.max((row.ha / maxHa) * 100, 2);
    const item = document.createElement('div');
    item.className = 'bar-item';
    const valLabel = document.createElement('div');
    valLabel.className = 'bar-label-val';
    valLabel.textContent = row.ha > 0 ? formatNumber(row.ha, 1) : '0';
    const fill = document.createElement('div');
    fill.className = `bar-fill ${color}`;
    fill.style.height = '0%';
    fill.title = `${row.year}: ${row.ha.toFixed(2)} ha`;
    const yearLabel = document.createElement('div');
    yearLabel.className = 'bar-label-year';
    yearLabel.textContent = row.year;
    item.appendChild(valLabel);
    item.appendChild(fill);
    item.appendChild(yearLabel);
    $barChart.appendChild(item);
    setTimeout(() => { fill.style.height = `${pct}%`; }, 100);
  });
}

function renderTreeLossColorForm(lat, lng, rows) {
  latestLossRows = rows;
  latestLossCenter = { lat, lng };
  treeLossColorLayer.clearLayers();
  const maxHa = Math.max(...rows.map(row => row.ha), 0);
  if (maxHa < 0.1) return;

  const radiusKm = parseInt($radiusInput.value, 10) || 10;
  const totalHa = rows.reduce((sum, row) => sum + row.ha, 0);
  const intensity = Math.min(Math.max(totalHa / 160, 0.18), 1);
  const centerRadius = Math.max(700, radiusKm * 230 * intensity);
  const midRadius = Math.max(centerRadius * 1.9, radiusKm * 430);
  const outerRadius = Math.max(midRadius * 1.65, radiusKm * 780);

  L.circle([lat, lng], {
    radius: outerRadius,
    stroke: false,
    fillColor: '#ffd166',
    fillOpacity: 0.11,
  }).bindTooltip('Outer tree loss influence').addTo(treeLossColorLayer);

  L.circle([lat, lng], {
    radius: midRadius,
    stroke: false,
    fillColor: '#ff9800',
    fillOpacity: 0.18 + intensity * 0.06,
  }).bindTooltip('Moderate tree loss zone').addTo(treeLossColorLayer);

  L.circle([lat, lng], {
    radius: centerRadius,
    stroke: false,
    fillColor: '#f44336',
    fillOpacity: 0.35 + intensity * 0.16,
  }).bindTooltip('Deforestation centre').addTo(treeLossColorLayer);

  const sortedRows = [...rows].sort((a, b) => b.ha - a.ha);
  sortedRows.forEach((row, index) => {
    if (row.ha < 0.1) return;
    const rowIntensity = row.ha / maxHa;
    const point = lossHotspotPoint(lat, lng, index, sortedRows.length, radiusKm, rowIntensity);
    const color = treeLossColor(rowIntensity, point.distanceRatio);
    L.circle([point.lat, point.lng], {
      radius: 360 + rowIntensity * 1750,
      color,
      fillColor: color,
      fillOpacity: 0.28 + rowIntensity * 0.42,
      weight: 0,
      opacity: 0.82,
    }).bindTooltip(`${row.year}: ${row.ha.toFixed(2)} ha lost`).addTo(treeLossColorLayer);
  });
  syncTreeLossLayer();
}

function lossHotspotPoint(lat, lng, index, count, radiusKm, intensity) {
  if (index < 2) {
    const closeOffset = index === 0 ? -0.0025 : 0.0025;
    return { lat: lat + closeOffset, lng: lng + closeOffset, distanceRatio: 0.12 };
  }

  const angle = ((index - 2) / Math.max(count - 2, 1)) * Math.PI * 2 + Math.PI / 5;
  const distanceRatio = 0.34 + (1 - intensity) * 0.34;
  const distanceKm = radiusKm * distanceRatio;
  const latOffset = (Math.sin(angle) * distanceKm) / 111;
  const lngOffset = (Math.cos(angle) * distanceKm) / (111 * Math.max(Math.cos(lat * Math.PI / 180), 0.18));
  return { lat: lat + latOffset, lng: lng + lngOffset, distanceRatio };
}

function treeLossColor(intensity, distanceRatio) {
  if (intensity > 0.66 && distanceRatio < 0.28) return '#f44336';
  if (intensity > 0.38 || distanceRatio < 0.55) return '#ff9800';
  return '#ffd166';
}

function getTreeLossMode() {
  return $treeLossMode?.value || 'dots';
}

function syncTreeLossLayer() {
  const enabled = $('toggle-tree-loss')?.checked ?? true;
  map.removeLayer(treeLossLayer);
  map.removeLayer(treeLossColorLayer);
  if (!enabled) return;

  if (getTreeLossMode() === 'color') {
    if (!treeLossColorLayer.getLayers().length && latestLossCenter && latestLossRows.length) {
      renderTreeLossColorForm(latestLossCenter.lat, latestLossCenter.lng, latestLossRows);
    }
    if (treeLossColorLayer.getLayers().length) map.addLayer(treeLossColorLayer);
    return;
  }

  map.addLayer(treeLossLayer);
}

// =============================================
// MAP MARKER
// =============================================
function placeMarker(lat, lng, severity) {
  if (currentMarker) map.removeLayer(currentMarker);
  const icon = L.divIcon({
    className: '',
    html: `<div class="custom-marker ${severity.color}"></div>`,
    iconSize: [40, 40],
    iconAnchor: [20, 40],
  });
  currentMarker = L.marker([lat, lng], { icon })
    .addTo(map)
    .bindPopup(`
      <div style="padding:4px 0">
        <strong style="font-size:14px">${severity.icon} ${severity.level}</strong><br/>
        <span style="font-size:11px;color:rgba(232,240,254,0.6)">${lat.toFixed(4)}, ${lng.toFixed(4)}</span>
      </div>
    `, { maxWidth: 220 });
}

// =============================================
// CLIMATE ENGINE (Open-Meteo — free, no API key)
// =============================================
async function fetchAndRenderClimate(lat, lng, totalHa) {
  try {
    const url = `${APIS.OPEN_METEO}/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m&timezone=auto`;
    const res = await fetch(url);
    const data = await res.json();
    const c = data.current;

    const temp     = c.temperature_2m;
    const humidity = c.relative_humidity_2m;
    const precip   = c.precipitation;
    const wind     = c.wind_speed_10m;

    $cvTemp.textContent     = `${temp}°`;
    $cvHumidity.textContent = `${humidity}%`;
    $cvPrecip.textContent   = `${precip}`;
    $cvWind.textContent     = `${wind}`;

    $cbTemp.style.width     = `${Math.min(Math.max(((temp + 20) / 70) * 100, 0), 100)}%`;
    $cbHumidity.style.width = `${humidity}%`;
    $cbPrecip.style.width   = `${Math.min(precip * 10, 100)}%`;
    $cbWind.style.width     = `${Math.min(wind / 150 * 100, 100)}%`;

    renderGlobalWarmingIndicator(temp, humidity, totalHa);

    $climatePlaceholder.classList.add('hidden');
    $climateContent.classList.remove('hidden');
  } catch (err) {
    console.warn('Climate fetch failed:', err.message);
    $climatePlaceholder.innerHTML = '<p style="color:rgba(232,240,254,0.3);font-size:12px">Climate data unavailable</p>';
  }
}

function renderGlobalWarmingIndicator(temp, humidity, totalHa) {
  const tempScore      = Math.max(0, (temp - 15) / 40);
  const humidityScore  = Math.max(0, (100 - humidity) / 100);
  const deforestScore  = Math.min(totalHa / 200, 1);
  const composite      = (tempScore * 0.4 + humidityScore * 0.3 + deforestScore * 0.3);
  const gaugePos       = Math.max(5, Math.min(composite * 100, 95));

  $gwGaugeFill.style.left = `${gaugePos}%`;

  let label, desc, color;
  if (composite < 0.25) {
    label = '🟢 Low Risk'; color = '#00e676';
    desc = 'Environmental conditions appear stable. Minimal indicators of climate stress or deforestation-driven warming.';
  } else if (composite < 0.5) {
    label = '🟡 Moderate Risk'; color = '#ffeb3b';
    desc = 'Some warming indicators detected. Temperature and humidity levels suggest early signs of climate stress.';
  } else if (composite < 0.75) {
    label = '🟠 High Risk'; color = '#ff9800';
    desc = 'Significant warming indicators. High temperature, reduced humidity, and notable deforestation suggest elevated climate impact.';
  } else {
    label = '🔴 Critical Risk'; color = '#f44336';
    desc = 'Severe environmental stress detected. This area shows strong indicators of deforestation-driven climate change and requires urgent action.';
  }

  $gwLabel.textContent = label;
  $gwLabel.style.color = color;
  $gwDescription.textContent = desc;
}

// =============================================
// UI STATE HELPERS
// =============================================
function showLoading() {
  $resultPlaceholder.classList.add('hidden');
  $resultContent.classList.add('hidden');
  $errorState.classList.add('hidden');
  $loadingState.classList.remove('hidden');
  $analyzeBtn.disabled = true;
  resetSteps();
}

function showError(message) {
  $loadingState.classList.add('hidden');
  $resultContent.classList.add('hidden');
  $resultPlaceholder.classList.add('hidden');
  $errorState.classList.remove('hidden');
  $errorMessage.textContent = message;
  $analyzeBtn.disabled = false;
}

function setStatus(type, text) {
  $statusText.textContent = text;
  $statusDot.className = 'status-dot';
  if (type === 'loading') $statusDot.classList.add('loading');
  if (type === 'error')   $statusDot.classList.add('error');
}

function setStep(index) {
  $steps.forEach((step, i) => {
    step.classList.remove('active', 'done');
    if (i < index) step.classList.add('done');
    if (i === index) step.classList.add('active');
  });
}

function resetSteps() { $steps.forEach(s => s.classList.remove('active', 'done')); }

/**
 * Clear visual UI layers and active location pointer.
 * Caches (apiCache / simCache) are preserved so the user
 * can toggle back or revisit a previous location.
 */
function clearMapLayers() {
  if (currentMarker)  { map.removeLayer(currentMarker);  currentMarker  = null; }
  if (currentPolygon) { map.removeLayer(currentPolygon); currentPolygon = null; }
  latestLossRows = [];
  latestLossCenter = null;
  treeLossColorLayer.clearLayers();
  // NOTE: appState.apiCache and appState.simCache intentionally NOT cleared.
}

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

function formatNumber(n, decimals = 0) {
  if (n === null || n === undefined || isNaN(n)) return '—';
  return n.toLocaleString('en-US', { maximumFractionDigits: decimals, minimumFractionDigits: decimals });
}

function formatCompact(n) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString([], {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}

function initGlobe() {
  if (globeScene || typeof THREE === 'undefined') return;
  const width = $globeContainer.clientWidth || window.innerWidth;
  const height = $globeContainer.clientHeight || window.innerHeight;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(32, width / height, 0.1, 100);
  camera.position.z = 3.1;
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(width, height);
  $globeContainer.appendChild(renderer.domElement);

  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(1, 64, 64),
    new THREE.MeshPhongMaterial({
      map: new THREE.TextureLoader().load('https://threejs.org/examples/textures/planets/earth_atmos_2048.jpg'),
      specular: new THREE.Color('#223344'),
      shininess: 12,
    })
  );
  scene.add(earth);
  scene.add(new THREE.AmbientLight('#7c93ad', 1.4));
  const sunlight = new THREE.DirectionalLight('#fff1d2', 2.2);
  sunlight.position.set(4, 2, 5);
  scene.add(sunlight);
  globeScene = {
    scene,
    camera,
    renderer,
    earth,
    raycaster: new THREE.Raycaster(),
    pointer: new THREE.Vector2(),
    isDragging: false,
    dragMoved: false,
    lastPointer: { x: 0, y: 0 },
    autoRotate: true,
  };
  bindGlobeControls();
  const animate = () => {
    if (!globeScene) return;
    if (globeScene.autoRotate && !globeScene.isDragging) earth.rotation.y += 0.0015;
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  };
  animate();
}

function resizeGlobe() {
  if (!globeScene) return;
  const width = $globeContainer.clientWidth || window.innerWidth;
  const height = $globeContainer.clientHeight || window.innerHeight;
  globeScene.camera.aspect = width / height;
  globeScene.camera.updateProjectionMatrix();
  globeScene.renderer.setSize(width, height);
}

window.addEventListener('resize', resizeGlobe);

function bindGlobeControls() {
  if (!globeScene) return;
  const canvas = globeScene.renderer.domElement;

  canvas.addEventListener('pointerdown', (event) => {
    globeScene.isDragging = true;
    globeScene.dragMoved = false;
    globeScene.lastPointer = { x: event.clientX, y: event.clientY };
    $globeContainer.classList.add('is-dragging');
    canvas.setPointerCapture?.(event.pointerId);
  });

  canvas.addEventListener('pointermove', (event) => {
    if (!globeScene?.isDragging) return;
    const dx = event.clientX - globeScene.lastPointer.x;
    const dy = event.clientY - globeScene.lastPointer.y;
    if (Math.abs(dx) + Math.abs(dy) > 3) globeScene.dragMoved = true;
    globeScene.earth.rotation.y += dx * 0.006;
    globeScene.earth.rotation.x = clamp(globeScene.earth.rotation.x + dy * 0.004, -1.2, 1.2);
    globeScene.lastPointer = { x: event.clientX, y: event.clientY };
  });

  canvas.addEventListener('pointerup', (event) => {
    if (!globeScene) return;
    canvas.releasePointerCapture?.(event.pointerId);
    $globeContainer.classList.remove('is-dragging');
    const shouldPick = !globeScene.dragMoved;
    globeScene.isDragging = false;
    if (shouldPick) pickGlobeCoordinates(event);
  });

  canvas.addEventListener('pointercancel', () => {
    if (!globeScene) return;
    globeScene.isDragging = false;
    $globeContainer.classList.remove('is-dragging');
  });

  canvas.addEventListener('wheel', (event) => {
    event.preventDefault();
    zoomGlobe(event.deltaY > 0 ? 0.22 : -0.22);
  }, { passive: false });

  $('globe-zoom-in')?.addEventListener('click', () => zoomGlobe(-0.28));
  $('globe-zoom-out')?.addEventListener('click', () => zoomGlobe(0.28));
  $('globe-reset')?.addEventListener('click', resetGlobeView);
  $('globe-spin')?.addEventListener('click', toggleGlobeSpin);
}

function zoomGlobe(delta) {
  if (!globeScene) return;
  globeScene.camera.position.z = clamp(globeScene.camera.position.z + delta, 1.65, 5.4);
}

function resetGlobeView() {
  if (!globeScene) return;
  globeScene.camera.position.z = 3.1;
  globeScene.earth.rotation.set(0, 0, 0);
  globeScene.autoRotate = true;
  updateGlobeSpinButton();
}

function toggleGlobeSpin() {
  if (!globeScene) return;
  globeScene.autoRotate = !globeScene.autoRotate;
  updateGlobeSpinButton();
}

function updateGlobeSpinButton() {
  const spinButton = $('globe-spin');
  if (!spinButton || !globeScene) return;
  spinButton.setAttribute('aria-pressed', String(globeScene.autoRotate));
}

function pickGlobeCoordinates(event) {
  if (!globeScene) return;
  const rect = globeScene.renderer.domElement.getBoundingClientRect();
  globeScene.pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  globeScene.pointer.y = -(((event.clientY - rect.top) / rect.height) * 2 - 1);
  globeScene.raycaster.setFromCamera(globeScene.pointer, globeScene.camera);
  const hit = globeScene.raycaster.intersectObject(globeScene.earth)[0];
  if (!hit) return;

  const localPoint = globeScene.earth.worldToLocal(hit.point.clone()).normalize();
  const lat = THREE.MathUtils.radToDeg(Math.asin(localPoint.y));
  const phi = Math.atan2(localPoint.z, -localPoint.x);
  const lng = normalizeLng(THREE.MathUtils.radToDeg(phi) - 180);

  $latInput.value = lat.toFixed(6);
  $lngInput.value = lng.toFixed(6);
  lastName = null;
  $locationSearch.value = '';
  updatePrefixes();
  setStatus('ready', `3D Earth selected ${lat.toFixed(4)}, ${lng.toFixed(4)} — click Analyze`);
}

function focusGlobeOnCoordinates(lat, lng) {
  if (!globeScene || !Number.isFinite(lat) || !Number.isFinite(lng)) return;
  const phi = THREE.MathUtils.degToRad(normalizeLng(lng) + 180);
  const theta = THREE.MathUtils.degToRad(90 - lat);
  const point = new THREE.Vector3(
    -Math.cos(phi) * Math.sin(theta),
    Math.cos(theta),
    Math.sin(phi) * Math.sin(theta)
  );
  globeScene.earth.rotation.y = -Math.atan2(point.x, point.z);
  globeScene.earth.rotation.x = Math.asin(point.y) * 0.45;
}

function normalizeLng(lng) {
  return ((((lng + 180) % 360) + 360) % 360) - 180;
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

// =============================================
// INIT
// =============================================
setStatus('ready', 'Ready to Analyze');
$analyzeBtn.disabled = false;
renderRecentSearches();

// Re-enable button when results show
const analyzeObserver = new MutationObserver(() => {
  if (!$resultContent.classList.contains('hidden') || !$errorState.classList.contains('hidden')) {
    $analyzeBtn.disabled = false;
  }
});
analyzeObserver.observe($resultContent, { attributes: true });
analyzeObserver.observe($errorState, { attributes: true });

console.log('%c🌳 ForestWatch loaded', 'color:#00e676;font-size:14px;font-weight:bold');
console.log('%c APIs wired from wri/gfw repo:', 'color:#42a5f5');
console.log('   1. GFW Data API    → data-api.globalforestwatch.org');
console.log('   2. Resource Watch  → api.resourcewatch.org');
console.log('   3. GNW Analytics   → analytics.globalnaturewatch.org');
console.log('   4. Climate Watch   → climatewatchdata.org');
console.log('   5. Open-Meteo      → api.open-meteo.com');
console.log('   6. Nominatim (OSM) → nominatim.openstreetmap.org');



// =============================================
// COORDINATE PREFIXES & SEARCH
// =============================================
function updatePrefixes() {
  const lat = parseFloat($latInput.value);
  const lng = parseFloat($lngInput.value);
  
  const latPrefix = document.getElementById('lat-prefix');
  if (latPrefix) {
    if (!isNaN(lat)) {
      latPrefix.textContent = lat >= 0 ? 'N' : 'S';
    } else {
      latPrefix.textContent = 'N/S';
    }
  }
  
  const lngPrefix = document.getElementById('lng-prefix');
  if (lngPrefix) {
    if (!isNaN(lng)) {
      lngPrefix.textContent = lng >= 0 ? 'E' : 'W';
    } else {
      lngPrefix.textContent = 'E/W';
    }
  }
}

$latInput.addEventListener('input', updatePrefixes);
$lngInput.addEventListener('input', updatePrefixes);

const coordsSearchBtn = document.getElementById('coords-search-btn');
if (coordsSearchBtn) {
  coordsSearchBtn.addEventListener('click', () => {
    $analyzeBtn.click();
  });
}
